package com.radrasyad.myapplication.data.model

data class Users(
    val login : String,
    val avatar_url : String,
    val id : Int

)
