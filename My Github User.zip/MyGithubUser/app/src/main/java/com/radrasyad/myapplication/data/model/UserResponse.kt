package com.radrasyad.myapplication.data.model

data class UserResponse(
    val items : ArrayList<Users>
)
